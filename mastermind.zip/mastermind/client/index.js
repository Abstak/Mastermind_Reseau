var game = new Phaser.Game(600, 850, Phaser.CANVAS, 'mastermind', {
  preload: preload,
  create: create,
  update: update,
  render: render
});

var jouer_x;
var jouer_y;

var solution_x;
var solution_y;

var fruits = ['banane', 'fraise', 'pomme', 'cerise', 'pasteque', 'orange', 'raisin', 'citron'];

var solution = [];
var solutionJoueur = [];

function preload() {
  // positions de départs du joueur
  jouer_x = 170;
  jouer_y = 600;

  //positions de départs de la solution
  solution_x = 155;
  solution_y = 70;

  //solution

  for (var i = 0; i < 4; i++) {
    solution[i] = fruits[Math.floor(Math.random()*7)];
    // solution.push(Math.random()*8+1); c'est équivalent
  }

  console.log(solution);

  //fonds
  game.load.image('frigo',   'images/frigo.png');
  game.load.image('palette', 'images/palette.png');

  //fruits
  game.load.image('banane',   'images/banane.png');
  game.load.image('fraise',   'images/fraise.png');
  game.load.image('pomme',    'images/pomme.png');
  game.load.image('cerise',   'images/cerise.png');
  game.load.image('pasteque', 'images/pasteque.png');
  game.load.image('orange',   'images/orange.png');
  game.load.image('raisin',   'images/raisin.png');
  game.load.image('citron',   'images/citron.png');

  // fruits solutions

  game.load.image('bananeco',   'images/bananeco.png');
  game.load.image('fraiseco',   'images/fraiseco.png');
  game.load.image('pommeco',    'images/pommeco.png');
  game.load.image('ceriseco',   'images/ceriseco.png');
  game.load.image('pastequeco', 'images/pastequeco.png');
  game.load.image('orangeco',   'images/orangeco.png');
  game.load.image('raisinco',   'images/raisinco.png');
  game.load.image('citronco',   'images/citronco.png');

}

function create() {
  game.add.tileSprite(0, 0, game.width, game.height, 'frigo');
  var paletteSprite = game.add.tileSprite(408, 440, 150, 213, 'palette');
  paletteSprite.inputEnabled = true;
  paletteSprite.events.onInputDown.add(checkFruit, this);
}

function update() {
}


function render() {
}


function checkFruit() {
  var x = game.input.x;
  var y = game.input.y;
  if (x > 442 && x < 475) {
    if (y > 457 && y < 488) {
      jouer("pomme");
    } else if (y > 503 && y < 530) {
      jouer("raisin");
    } else if (y > 542 && y < 574) {
      jouer("banane");
    } else if (y > 584 && y < 619) {
      jouer("cerise");
    }
  } else if (x > 491 && x <523) {
    if (y > 457 && y < 488) {
      jouer("orange");
    } else if (y > 503 && y < 530) {
      jouer("pasteque");
    } else if (y > 542 && y < 574) {
      jouer("citron");
    } else if (y > 584 && y < 619) {
      jouer("fraise");
    }
  }
}

function jouer(fruit) {
  game.add.tileSprite(jouer_x, jouer_y, 40, 40, fruit);

  solutionJoueur[solutionJoueur.length] = fruit;
  // solutionJoueur.push(fruit) est équivalent

  console.log(solutionJoueur);
  jouer_x += 50;

  verification();

  // si jamais on a 4 fruits, alors on remets nos valeurs à 0
  if (solutionJoueur.length == 4) {
    jouer_x = 170; // on remet valeur par défaut
    jouer_y -= 50; // on remonte sur y
    solutionJoueur = [];
  }
}

function verification() {
  // on vérifie si nos deux solutions sont égales à l'aide de notre méthode
  if (solutionJoueur.equals(solution)) {
    for (var i = 0; i < solution.length; i++) {
      var elem = solution[i]; // elem courant de la solution, on va itérer 4 fois
      game.add.tileSprite(solution_x + i*50, solution_y, 65, 57, elem + "co"); // on rajoute le co pour les images gagnantes
    }
  }
}

function indices() {

}


/*
  this est un mot clé, qui signifie l'objet courant
  en gros sur cette fonction
  on appele par ex: monTableau.equals(solution)
  dans la fonction equals, this sera la valeur de monTableau
*/

Array.prototype.equals = function (tableau) {
  // si jamais le tableau passé en paramètre est null alors on renvoie faux
  if (!tableau)
    return false;

  // si jamais ils n'ont pas la même taille
  // on a pas besoin de comparer chacune de leur valeur, ils sont forcément pas égaux
  if (this.length != tableau.length)
    return false;

  for (var i = 0; i < this.length; i++) {
    if (this[i] != tableau[i]) {
      return false;
    }
  }

  return true;
};
