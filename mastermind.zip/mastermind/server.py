from flask import Flask, current_app
app = Flask(__name__)
with app.app_context():
    # within this block, current_app points to app.
    print current_app.name

@app.send_static_file('index.html')

@app.route('/')
def hello():
    return "hello world"

if __name__ == "__main__":
    app.run()
