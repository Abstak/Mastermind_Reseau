'use strict';

var express = require('express');
var app = express();
var server = require('http').createServer(app);

app.set('port', 5000);

app.use('/', express.static(__dirname + "/client"));

server.listen(app.get('port'), (err) => {
  if (err) throw err;
  console.log('server listening on port:' + app.get('port'));
});
